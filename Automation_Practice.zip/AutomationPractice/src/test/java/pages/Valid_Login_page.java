package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.excelutility.Excel;

public class Valid_Login_page {
	WebDriver driver;
	public void Launch(String browser, String url) //method for launching multi browsers
	{
	if(browser.equalsIgnoreCase("chrome")) // for chrome
	{
	System.setProperty("webdriver.chrome.driver", "C:\\project\\alekya1\\AutomationPractice\\Drivers\\chromedriver.exe");
	// opens chrome browser
	driver=new ChromeDriver();

	}
	else if(browser.equalsIgnoreCase("internetexplorer")) // for internet explorer
	{
		System.setProperty("webdriver.ie.driver", "C:\\project\\alekya1\\AutomationPractice\\Drivers\\IEDriverServer.exe");
		// opens internet browser
		driver=new InternetExplorerDriver();
	
	}
	driver.manage().window().maximize(); // to maximize window
	driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS); // to implicitly wait
	driver.get("https://google.com"); // prints the title
System.out.println(driver.getTitle()); // prints the title

}
	public void Signin(String xpath)  // method for signin of the Loga Automation Practice website
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	public void usernameandpassword(int i) throws IOException  // method for reading username and password through excel sheet
	{
		Excel e=new Excel();
		driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(e.excel_username(i)); // reads username through excel sheet
		WebElement d = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		d.click();
		driver.findElement(By.xpath("//*[@id=\"passwd\"]")).sendKeys(e.excel_password(i)); // reads password through excel sheet
		WebElement f = driver.findElement(By.xpath("//*[@id=\"passwd\"]"));
		f.click();
	
	}
	public void Click(String xpath) // method for clicking signin after entering username and password
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	public void Assertn(String xpath)
	{
		String s1 = driver.findElement(By.xpath(xpath)).getText(); // prints the text
		Assert.assertEquals("Welcome to your account. Here you can manage all of your personal information and orders.\r\n" + "\r\n" + "", s1);
		// compares the expected and actual result
		System.out.println("login successful"); // prints login is successful
	}
	public void valid_login() throws IOException // for screenshot
	{
		TakesScreenshot t = (TakesScreenshot)driver;
		File f = t.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File("C:\\project\\alekya1\\AutomationPractice\\Screenshots\\validlogin.png"));
		// screenshot of valid login page
	}
	
}
