package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Valid_Regstn_page {
	WebDriver driver;
	public void Launching(String browser,String URL) //method for launching multi browsers
	{
		if(browser.equalsIgnoreCase("chrome")) // for chrome
		{
		System.setProperty("webdriver.chrome.driver", "C:\\project\\alekya1\\AutomationPractice\\Drivers\\chromedriver.exe");
		// opens chrome browser
		driver=new ChromeDriver();
		
		}
		else if(browser.equalsIgnoreCase("internetexplorer")) // for internet explorer
		{
			System.setProperty("webdriver.ie.driver", "C:\\project\\alekya1\\AutomationPractice\\Drivers\\IEDriverServer.exe");
			// opens internet browser
			driver=new InternetExplorerDriver();
			
		}
		driver.manage().window().maximize(); // to maximize window
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS); // to implicitly wait
		driver.get("https://google.com"); // opens google
	System.out.println(driver.getTitle()); // prints the title
	}
	public void Entering(String xpath,String values) // method for entering registration details such as first name, last name, address, mobile number etc..
	{
		driver.findElement(By.xpath(xpath)).sendKeys(values);
	}
	public void clicking(String xpath) // method for clicking create an account after entering all the details
	{
		driver.findElement(By.xpath(xpath)).click();
	}
	public void AsseRtion(String xpath)
	{
		String s1 = driver.findElement(By.xpath(xpath)).getText(); // prints the text
		Assert.assertEquals("Welcome to your account. Here you can manage all of your personal information and orders.", s1); 
		// compares the actual and expected strings
		System.out.println("Registration successful"); // prints registration is successful
	}
	public void invalid_login() throws IOException // for screenshot
	{
		TakesScreenshot t = (TakesScreenshot)driver;
		File f = t.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File("C:\\project\\alekya1\\AutomationPractice\\Screenshots\\validRegistration.png"));
		// screenshot of valid registration page
	}
	}



