package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Signout_page {
	WebDriver driver;
	public void Launching(String browser,String URL) //method for launching multi browsers
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "C:\\project\\alekya1\\AutomationPractice\\Drivers\\chromedriver.exe");
		// opens chrome browser
		driver=new ChromeDriver();
		
		}
		else if(browser.equalsIgnoreCase("internetexplorer"))
		{
			System.setProperty("webdriver.ie.driver", "C:\\project\\alekya1\\AutomationPractice\\Drivers\\IEDriverServer.exe");
			// opens internet explorer
			driver=new InternetExplorerDriver();
			
		}
		driver.manage().window().maximize(); // to maximize window
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS); // to implicitly wait
		driver.get("https://google.com"); // opens google
System.out.println(driver.getTitle()); // prints the title
	}
public void click(String xpath) // method for clicking Sign in and Sign out
{
	driver.findElement(By.xpath(xpath)).click();
}
public void entering(String xpath, String value) // method for entering user name and password while signing into the account
{
	driver.findElement(By.xpath(xpath)).sendKeys(value);
}
public void assertion(String xpath)
{
	String s1 = driver.findElement(By.xpath(xpath)).getText(); // prints the text
	Assert.assertEquals("ALREADY REGISTERED?", s1); // compares expected and actual strings 
	System.out.println("signout successful"); // prints signout is successful
} 
public void invalid_login() throws IOException // for screenshot
{
	TakesScreenshot t = (TakesScreenshot)driver;
	File f = t.getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(f, new File("C:\\project\\alekya1\\AutomationPractice\\Screenshots\\signout.png"));
	// screenshot of signout page
}
}
