package stepdefinition;

import java.io.IOException;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Invalid_Login_page;

public class Invalid_Login_stepdefinition {
	Invalid_Login_page ilp = new Invalid_Login_page();
	@Given("^Open the url in the browser$")
	public void open_the_url_in_the_browser()  {
		// launchs chrome browser
		 ilp.Launch("chrome", "http://automationpractice.com/index.php"); 
		 // Launching Loga Automation Practice website by entering the url
		
	}

	@When("^click Signin$")
	public void click_Signin()  {
		ilp.Click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a"); 
		// Inspected signin button by its xpath and clicking signin
		
	}

	@When("^Enter invalid Usernameandpassword$")
	public void enter_invalid_Usernameandpassword() throws IOException   {
		for(int j=1;j<=2;j++)
		{
			ilp.usernameandpassword(j);
			ilp.Click("//*[@id=\"SubmitLogin\"]/span"); 
			if(j<=2)
			{
				ilp.Launch("chrome", "http://automationpractice.com/index.php"); 
				ilp.Click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a"); 
	   // user name and password read through the data given in the excel sheet and following is the code
			}
		}
	}

	@Then("^Click on Signin$")
	public void click_on_Signin()  {
		ilp.Click("//*[@id=\"SubmitLogin\"]/span");  
		  // Inspected signin button by its xpath and clicked on Signin
		
	}

	@Then("^popuP message is displayed$")
	public void popup_message_is_displayed() {
		ilp.Assertion("//*[@id=\"center_column\"]/div[1]/ol/li");
		// Pop message will be displayed on unsuccessful login 
			}
	}

