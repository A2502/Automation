package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Valid_Regstn_page;

public class Valid_Redstn_stepdefinition {
	Valid_Regstn_page vrp = new Valid_Regstn_page();
	@Given("^open URL in chrome browser$")
	public void open_URL_in_chrome_browser()  {
	  vrp.Launching("chrome", "http://automationpractice.com/index.php");
	// Launching Loga Automation Practice website by entering the url 
	}

	@When("^Enter an email$")
	public void enter_an_email()  {
	vrp.Entering("//*[@id=\"email_create\"]", "alekyanaidu2502@gmail.com");
	// Inspected email text box by its xpath and entering the email in the email text box
	}

	@Then("^click on create an account$")
	public void click_on_create_an_account() {
	    vrp.clicking("//*[@id=\"SubmitCreate\"]/span");
	 // Inspected create an account button by its xpath and clicking create an account
	}

	@Then("^select title$")
	public void select_title() {
		vrp.clicking("//*[@id=\"id_gender2\"]");
		// Inspected select title radio button by its xpath and selecting the title
	}

	@Then("^enter first name$")
	public void enter_first_name() {
	    vrp.Entering("//*[@id=\"customer_firstname\"]","Srishty");
	 // Inspected first name text box by its xpath and entering first name
	 	
	}

	@Then("^enter last name$")
	public void enter_last_name() {
	    vrp.Entering("//*[@id=\"customer_lastname\"]", "manchem");
	 // Inspected last name text box by its xpath and entering last name
	}

	@Then("^enter email$")
	public void enter_email() {
	   vrp.Entering("//*[@id=\"email\"]", "alekyanaidu2502@gmail.com");
	    // Inspected email text box by its xpath and entering email 
	}

	@Then("^enter password$")
	public void enter_password()  {
	    vrp.Entering("//*[@id=\"passwd\"]", "srisHty@2512");
	 // Inspected password textbox by its xpath and entering password
	}

	@Then("^select dob$")
	public void select_dob() {
		   vrp.clicking("//*[@id=\"days\"]");
		   vrp.clicking("//*[@id=\"days\"]/option[18]");
		   vrp.clicking("//*[@id=\"months\"]");
		   vrp.clicking("//*[@id=\"months\"]/option[11]");
		   vrp.clicking("//*[@id=\"years\"]");
		   vrp.clicking("//*[@id=\"years\"]/option[26]");  
		// Inspected day,month,year radio buttons by its xpath and entering dob
	}

	@Then("^enter first name in address$")
	public void enter_first_name_in_address()  {
		vrp.Entering("//*[@id=\"firstname\"]", "Srishty");  
		// Inspected first name text box by its xpath and entering first name
	
	}

	@Then("^enter last name in address$")
	public void enter_last_name_in_address()  {
		vrp.Entering("//*[@id=\"lastname\"]", "manchem");
		// Inspected last name text box by its xpath and entering last name
	}
	

	@Then("^enter company in address$")
	public void enter_company_in_address() {
		vrp.Entering("//*[@id=\"company\"]", "cts"); 
		// Inspected company name text box by its xpath and entering company name
	
	}

	@Then("^enter address$")
	public void enter_address()  {
		vrp.Entering("//*[@id=\"address1\"]", "fisrt street, 12-4-1"); 
		// Inspected address text box by its xpath and entering address
	}

	@Then("^enter address line(\\d+)$")
	public void enter_address_line(int arg1)  {
		vrp.Entering("//*[@id=\"address2\"]", "shaikspeare street");
		// Inspected address line2 text box by its xpath and entering company name
	
	}

	@Then("^enter city$")
	public void enter_city()  {
		vrp.Entering("//*[@id=\"city\"]", "aldshj"); 
		// Inspected city text box by its xpath and entering city
	
	}

	@Then("^select state$")
	public void select_state()  {
		vrp.clicking("//*[@id=\"id_state\"]");
		   vrp.clicking("//*[@id=\"id_state\"]/option[11]");  
		   // Inspected state dropdown by its xpath and selecting the state
	
	}

	@Then("^enter zip postal code$")
	public void enter_zip_postal_code()  {
		vrp.Entering("//*[@id=\"postcode\"]", "50426");
		// Inspected zip code text box by its xpath and entering zip code

	}

	@Then("^select country$")
	public void select_country()  {
		 vrp.clicking("//*[@id=\"id_country\"]");  
		vrp.clicking("//*[@id=\"id_country\"]/option[2]"); 
		  // Inspected Country dropdown and selecting the country
	

	}

	@Then("^enter additional information$")
	public void enter_additional_information()  {
		vrp.Entering("//*[@id=\"other\"]", "alekyacom");
		// Inspected additional information text box by its xpath and entering additional information
	
	}

	@Then("^enter home phone$")
	public void enter_home_phone()  {
		vrp.Entering("//*[@id=\"phone\"]", "8814528452");
		// Inspected home phone text box by its xpath and entering home phone
	
	}

	@Then("^enter mobile phone$")
	public void enter_mobile_phone()  {
		vrp.Entering("//*[@id=\"phone_mobile\"]", "9515748522");
		// Inspected mobile phone text box by its xpath and entering mobile phone
	   
	}

	@Then("^enter assign an address$")
	public void enter_assign_an_address() {
		vrp.Entering("//*[@id=\"alias\"]", "fgfcgbvnh");
		// Inspected assign address text box by its xpath and entering address
	  
	}

	@Then("^click on register$")
	public void click_on_register() {
	      vrp.clicking("//*[@id=\"submitAccount\"]/span");
	        // clicks on register after entering all the details
	}

	@Then("^popup message is displayed$")
	public void popup_message_is_displayed()  {
		vrp.AsseRtion("//*[@id=\"center_column\"]/p");
		   
		// Pop message will be displayed on successful registration 
	}	    
}
