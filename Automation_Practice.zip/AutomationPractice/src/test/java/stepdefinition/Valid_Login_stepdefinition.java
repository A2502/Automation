package stepdefinition;

import java.io.IOException;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Valid_Login_page;

public class Valid_Login_stepdefinition {
	Valid_Login_page vlp = new Valid_Login_page();
	@Given("^Open the URL in the browser$")
	public void open_the_URL_in_the_browser()  {
		vlp.Launch("chrome","http://automationpractice.com/index.php");
		// Opening the Loga Automation Practice website by entering url 
		
	}

	@When("^click signin$")
	public void click_signin()  {
		vlp.Click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");
		 // Inspected signin button by its xpath and clicking signin
		
	}

	@When("^Enter valid Usernameandpassword$")
	public void enter_valid_Usernameandpassword() throws IOException  {
		for(int i=1;i<=2;i++)
		{
			vlp.usernameandpassword(i);
			vlp.Click("//*[@id=\"SubmitLogin\"]/span"); 
			if(i<=2)
			{
				vlp.Launch("chrome","http://automationpractice.com/index.php");
				vlp.Click("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");
	   // user name and password read through the data given in the excel sheet and following is the code
			}
		}
	}

	@Then("^Click on signin$")
	public void click_on_signin()  {
		vlp.Click("//*[@id=\"SubmitLogin\"]/span");  
		  // Inspected signin button by its xpath and clicked on Signin
		
	}

	@Then("^popup Message is displayed$")
	public void popup_Message_is_displayed()  {
		vlp.Assertn("//*[@id=\"center_column\"]/p"); 
		  // pop up message will be displayed on successful login 
		
	}


}
